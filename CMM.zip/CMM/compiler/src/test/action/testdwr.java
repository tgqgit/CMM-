package test.action;

public class testdwr {
    public String helloDwr(String username){
        return username+"hello!";
    }
}
